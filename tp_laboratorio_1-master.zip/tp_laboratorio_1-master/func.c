#include <stdio.h>
#include "func.h"

/**
* \brief Recibe un numero
* \param mensaje[] Se puede setear el mensaje que aparecera cuando la funcion es llamada
* \param numero Guarda el numero ingresado en la variable buffer
* \return Devuelve ese numero (guardado en buffer) para luego ser guardado en num1 y num2 cuando se llame a la funcion desde el main
*/
double obtenerNum(char mensaje[], double numero)
{
    double buffer;

    printf("%s",mensaje);
    scanf("%lf",&buffer);
    printf("\nValor ingresado OK.\n\n");

    return buffer;
}


/**
* \brief Suma dos numeros
* \param valorA El primer numero a sumar
* \param valorB El segundo numero a sumar
* \return En este caso no devuelve nada ya que el resultado se imprime en pantalla mediante printf. Por esa razon la funcion es void (no devuelve nada)
*/
void suma (double valorA, double valorB)
{
    printf("\nEl resultado de la suma es: %.2lf\n\n", (valorA + valorB));
    return 0;
}


/**
* \brief Resta dos numeros
* \param valorA El primer numero a restar
* \param valorB El segundo numero a restar
* \return En este caso no devuelve nada ya que el resultado se imprime en pantalla mediante printf. Por esa razon la funcion es void (no devuelve nada)
*/
void resta (double valorA, double valorB)
{
    printf("\nEl resultado de la resta es: %.2lf\n\n", (valorA - valorB));
    return 0;
}


/**
* \brief Multiplica dos numeros
* \param valorA El primer numero a multiplicar
* \param valorB El segundo numero a multiplicar
* \return En este caso no devuelve nada ya que el resultado se imprime en pantalla mediante printf. Por esa razon la funcion es void (no devuelve nada)
*/
void multiplicacion (double valorA, double valorB)
{
    printf("\nEl resultado de la multiplicacion es: %.2lf\n\n", (valorA * valorB));
    return 0;
}


/**
* \brief Valida si el usuario ingreso 0 (cero) como divisor, arroja un error y pide de nuevo un numero distinto a 0 (cero)
* \param valorB El numero a validar
* \return Devuelve valorB para ser utilizado en la funcion division
*/
double validarDivisor (double valorB)
{
    while (valorB == 0)
    {
        valorB = obtenerNum("\nError, no ingrese 0 como divisor. Reingrese: ", 1);
    }

    return valorB;
}


/**
* \brief Divide dos numeros
* \param valorA El dividendo
* \param valorB El divisor
* \return En este caso no devuelve nada ya que el resultado se imprime en pantalla mediante printf. Por esa razon la funcion es void (no devuelve nada)
*/
void division (double valorA, double valorB)
{
    printf("\nEl resultado de la division es: %.2lf\n\n", (valorA / valorB));
    return 0;
}


/**
* \brief Valida si el usuario ingreso un numero negativo o mayor a 170, arroja un error y pide de nuevo un numero positivo que no supere 170 (por los limites de double)
* \param valorA El numero a validar
* \return Devuelve valorA para ser utilizado en la funcion factorial
*/
double validarFactorial (double valorA)
{
    while((valorA < 0) || (valorA > 170))
    {
        valorA = obtenerNum("\nError, no ingrese negativos ni numeros mayores a 170 para calcular factorial. Reingrese: \n\n", 1);
    }

    return valorA;
}


/**
* \brief Calcula el factorial del primer numero mediante un bucle for
* \param valorA el numero a calcular el factorial
* \return En este caso no devuelve nada ya que el resultado se imprime en pantalla mediante printf. Por esa razon la funcion es void (no devuelve nada)
*/
void factorial(double valorA)
{
    int i;
    double resultado=1;

    for(i=1; i<=valorA; i++)
    {
        resultado*=i;
    }

    printf("\nEl factorial de %.2lf es: %.2lf\n\n", valorA, (resultado));
    return 0;
}


/**
* \brief Valida que el usuario ingrese solo las opciones del menu (1-9)
* \return En este caso no devuelve nada ya que el error es mostrado en pantalla mediante printf. Por esa razon la funcion es void (no devuelve nada)
*/
void ManejoError (void)
{
    printf("\nOpcion invalida. Reintente nuevamente\n\n");
    fflush(stdin);
    return 0;
}


/**
* \brief Utilizada para ingresar las opciones del menu
* \return Devuelve el valor seleccionado de opcion
*/
int seleccionarOpcion (void)
{
    int opcion;

    scanf("%d", &opcion);

    return opcion;
}



