#include <stdio.h>
#include <stdlib.h>
#include "func.h"

int main()
{
    char seguir = 's';
    double num1, num2;
    char num1_In, num2_In = 0; // Ceclaro dos banderas para verificar si el usuario ingreso o no los numeros y de lo contrario arrojar error.

    while(seguir=='s')
    {
        printf("1- Ingresar 1er operando(Numero 1=%.2lf)\n",num1);
        printf("2- Ingresar 2do operando(Numero 2=%.2lf)\n",num2);
        printf("3- Calcular la suma\n");
        printf("4- Calcula la resta\n");
        printf("5- Calcular la division\n");
        printf("6- Calcular la multiplicacion\n");
        printf("7- Calcular el factorial\n");
        printf("8- Calcular todas las operaciones\n");
        printf("9- Salir\n\n");

        switch(seleccionarOpcion())
        {
        case 1:
            if(num1_In == 0)  // Uso de la bandera. Si el usuario ingresa un numero, la variable se incrementa. De lo contrario, mas adelante cuando se quiera realizar una operacion, arroja error.
            {
                num1_In++;
            }
            num1 = obtenerNum("\nIngrese el primer operando: \n\n", num1);
            break;

        case 2:
            if(num2_In == 0) // Uso de la bandera. Si el usuario ingresa un numero, la variable se incrementa. De lo contrario, mas adelante cuando se quiera realizar una operacion, arroja error.
            {
                num2_In++;
            }
            num2 = obtenerNum("\nIngrese el segundo operando: \n\n", num2);
            break;

        case 3:
            if((num1_In != 1) || (num2_In != 1)) // Si alguna de los dos numeros no se ingreso (no se incremento la variable), arroja error.
            {
                printf("\nError. Ingrese ambos numeros.\n\n");
                break;
            }

            else
            {
                suma(num1, num2);
            }

            break;

        case 4:
            if((num1_In != 1) || (num2_In != 1))
            {
                printf("\nError. Ingrese ambos numeros.\n\n");
                break;
            }

            else
            {
                resta(num1, num2);
            }
            break;

        case 5:
            if((num1_In != 1) || (num2_In != 1))
            {
                printf("\nError. Ingrese ambos numeros.\n\n");
                break;
            }

            else
            {
                num2=validarDivisor(num2);
                division(num1,num2);
            }
            break;

        case 6:
            if((num1_In != 1) || (num2_In != 1))
            {
                printf("\nError. Ingrese ambos numeros.\n\n");
                break;
            }
            else
            {
                multiplicacion(num1, num2);
            }
            break;

        case 7:
            if((num1_In != 1))
            {
                printf("\nError. Ingrese ambos numeros.\n\n");
                break;
            }

            else
            {
                num1=validarFactorial(num1);
                factorial(num1);
            }
            break;

        case 8:
            if((num1_In != 1) || (num2_In != 1))
            {
                printf("\nError. Ingrese ambos numeros.\n\n");
                break;
            }

            else
            {
                suma(num1, num2);
                resta(num1, num2);
                num2=validarDivisor(num2);
                division(num1,num2);
                multiplicacion(num1, num2);
                num1=validarFactorial(num1);
                factorial(num1);
            }
            break;

        case 9:
            seguir = 'n';
            break;

        default:
            ManejoError();
        }
    }

    return 0;
}
