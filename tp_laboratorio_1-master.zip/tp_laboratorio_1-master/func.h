/* Modulo de headers */

double  obtenerNum  (char mensaje[], double numero);

void    suma    (double valorA, double valorB);
void    resta   (double valorA, double valorB);
void    multiplicacion  (double a, double valorB);
void    division    (double valorA, double valorB);
void    factorial   (double valorA);

double  validarDivisor  (double valorB);
double  validarFactorial    (double valorB);

int seleccionarOpcion   (void);
void    ManejoError (void);
