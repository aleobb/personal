#include <stdio.h>
#include <stdlib.h>

struct EPersona
{

    char nombre[32];
    char apellido[32];
    char apellidoAux[32];
    int edad;
};

int main()
{
    int cant;
    char seguir = 's';
    int opcion;

    FILE *bin;
    struct EPersona personas;
   // struct EPersona auxiliar;
    bin=fopen("BIN.DAT","ab");

    do
    {
        printf("\n1- Alta de usuario \n");
        printf("\n2- Busqueda de usuario \n");
        printf("\n3- Imprimir usuarios \n");
        printf("\n4- Salir \n");
        printf("\nElija una opcion: ");
        scanf("%d",&opcion);
        fflush(stdin);

        switch(opcion)
        {
        case 1:
            printf("\nIngrese el nombre: ");
            gets(personas.nombre);
            fflush(stdin);
            printf("Ingrese el apellido: ");
            gets(personas.apellido);
            fflush(stdin);
            printf("Ingrese la edad: ");
            scanf("%d",&personas.edad);
            fflush(stdin);
            fwrite(&personas,sizeof(personas),1,bin);
            fclose(bin);
            break;

        case 2:
            /*bin=fopen("BIN.DAT","ab");
            printf("\nIngrese apellido: ");
            gets(auxiliar.apellido);

            if ((bin=fopen("BIN.DAT","rb"))==NULL)
            {
                printf("No se pudo abrir el archivo.");
                exit(1);
            }
            else
            {
                while(!feof(bin))
                {
                    cant=fread((&auxiliar),sizeof(auxiliar),1,bin);
                    if((strcmp(auxiliar.apellido,personas.apellido))==0 )
                    {
                        printf("\n%s\t%s\t%d\n\n",auxiliar.nombre,auxiliar.apellido,auxiliar.edad);
                        cant=0;
                        break;
                    }
                }
                if(cant!=1)
                    printf("No existe el usuario.");
                fclose(bin);
            }

        }*/
        printf("No implementado. Codigo a medias.\n\n\n");
        break;
    case 3:
        if ((bin=fopen("BIN.DAT","rb"))==NULL)
        {
            printf("No se pudo abrir el archivo.");
            exit(1);
        }
        while(!feof(bin))
        {
            cant=fread(&personas,sizeof(personas),1,bin);
            if(cant!=1)
            {
                if(feof(bin))
                    break;
                else
                {
                    printf("No se pudo leer el archivo.");
                    break;
                }
            }
            printf("\n%s\t%s\t%d\n\n",personas.nombre,personas.apellido,personas.edad);
        }
        fclose(bin);
        break;

    case 4:
        seguir = 'n';

        break;
    }
}
while(seguir=='s');

}
