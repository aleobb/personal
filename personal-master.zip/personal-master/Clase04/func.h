float promedio(int edad[], int cantidad);
