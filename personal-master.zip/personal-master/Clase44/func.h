float promedio(int edad[], int cantidad);
int minimo(int edad[], int a);
int maximo(int edad[], int a);
//void compactar(int edad[], int indice, int size);
int compactar(int array[], int size, int indice);
//int ordenar(int edad[], int )
int indiceMin(int array[], int size);
void ordenar (int array[], int size, int arrayOrdenado[]);
