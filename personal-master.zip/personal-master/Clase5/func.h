float promedio(int edad[], int cantidad);
int compactar(int array[], int size, int indice);
int calcularIndiceMinimo(int array[], int size);
void nadiaSort(int array[], int size,int arrayOrdenado[]);

