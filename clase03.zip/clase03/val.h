int obtenerInt(char mensaje[], char mensajeError[], int maximo, int minimo);
