float division(float a, float b)
{
    float resultado;
    resultado=a/b;
    return resultado;
}

float multiplicacion(float a, float b)
{
    float resultado;
    resultado=a*b;
    return resultado;
}

float suma(float a, float b)
{
    float resultado;
    resultado=a+b;
    return resultado;
}

float resta(float a, float b)
{
    float resultado;
    resultado=a-b;
    return resultado;
}

/*float factorial(float a, float b)
{
    float resultado;
    resultado=a-b;
    return resultado;
}
*/
