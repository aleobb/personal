#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
// .h prototipos
// .c desarrollo de las funciones


float main()
{
    float x,y,z;
    printf("Ingrese dividendo: ");
    scanf("%f",&x);
    printf("Ingrese divisor: ");
    scanf("%f",&y);
    z=division(x,y);
    printf("El resultado de la division es %.2f",z);

}

