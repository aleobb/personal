float division(float a, float b);
float suma(float a, float b);
float resta(float a, float b);
float multiplicacion(float a, float b);
float factorial(float a, float b);
