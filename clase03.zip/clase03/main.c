#include <stdio.h>
#include <stdlib.h>
#include "val.h"

int main()
{
int edad;
edad=obtenerInt("Ingrese su edad: ", "Error, reingrese: ", 100, 0);
printf("Su edad es: %d",edad);
return 0;
}
