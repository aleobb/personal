//Debemos lograr mostrar un mensaje al presionar el botón  'MOSTRAR'.
function Mostrar()
{
	alert("Funciona 1-EntradaSalida");

	var base;
	var perimetro;

	base = parseInt(prompt("Ingrese la base del triangulo"));

	perimetro = base + base + base;

	alert("El perimetro del triangulo es " + perimetro);
	
}

