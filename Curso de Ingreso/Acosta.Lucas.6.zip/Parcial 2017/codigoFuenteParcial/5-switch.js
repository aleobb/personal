//Debemos lograr mostrar un mensaje al presionar el botón  'MOSTRAR'.
function Mostrar()
{
	alert("Funciona 5-Switch");

	var mes;

	mes = prompt("Ingrese el mes del año.");
	

	switch(mes){
		case "enero":
		case "febrero":
		alert("Veranito!!!!");
		break;
		default:
		alert("extraño enero y febrero!!!");

		// respeto las mayusculas y minusculas tal como figuran en el enunciado del ejercicio

	}
	
}

