//Debemos lograr mostrar un mensaje al presionar el botón  'MOSTRAR'.
function Mostrar()
{
	alert("Funciona 3-EntradaSalida");

	var largo;
	var ancho;
	var metros;

	largo = document.getElementById("largo").value;
	ancho = document.getElementById("ancho").value;

	metros = (largo * 2 + ancho * 2)*6;

	alert("Se necesitan " + metros + " metros de alambre.");


	
}

