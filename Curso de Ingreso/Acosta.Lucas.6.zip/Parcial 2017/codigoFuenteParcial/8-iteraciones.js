//Debemos lograr mostrar un mensaje al presionar el botón  'MOSTRAR'.
function Mostrar() {
	alert("Funciona 8-iteraciones");

	var numero;
	var suma = 0;
	var promedio;
	var min = false;
	var max = 0;
	var cantPares = 0;
	var contador = 0;

	do {
		numero = parseInt(prompt("Ingrese un numero."));
		while (isNaN(numero) || numero < 1) // elijo no tomar el 0 como positivo
		{
			numero = parseInt(prompt("Error. Reingrese el numero."));

		}

		if (numero % 2 == 0) {
			cantPares++;
		}

		if (numero < min || min == false) {
			min = numero;
		}

		if (numero > max) {
			max = numero;
		}


		contador++;

		suma = suma + numero;
		promedio = suma / contador;


	}



	while (confirm("Desea continuar?"));

	document.write("La cantidad de numeros pares es " + cantPares + "</br>");
	document.write("El promedio de todos los numeros es " + promedio + "</br>");
	document.write("La suma de todos los numeros es " + suma + "</br>");
	document.write("El maximo numero es " + max + "</br>");
	document.write("El minimo numero es " + min);



}

