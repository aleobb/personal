//Debemos lograr mostrar un mensaje al presionar el botón  'MOSTRAR'.
function Mostrar()
{
	alert("Funciona 4-if");

	var num1;
	var num2;
	var resultado;

	num1 = parseInt(prompt("Ingrese el primer numero."));
	num2 = parseInt(prompt("Ingrese el segundo numero."));

	if(num1 == num2){

		resultado = num1 * num2;

	}else if (num1 > num2){

		resultado = num1 - num2;

	} else{

		resultado = num1 + num2;

		}

document.write("El resultado de la operacion es " + resultado);

}

