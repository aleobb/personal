//Debemos lograr mostrar un mensaje al presionar el botón  'MOSTRAR'.
function Mostrar() {
	alert("Funciona 7-iteraciones");

	var nota;
	var sexo;
	var suma = 0;
	var promedio;
	var notaBaja;
	var notaBajaAlum; // variabla para saber que alumno tiene la nota mas baja
	var varones = 0; // contador para saber cuantos varones se sacaron 6 o mas


	for (i = 1; i <= 6; i++) {
		nota = parseInt(prompt("Ingrese la nota del alumno " + i));
		while (isNaN(nota) || nota < 0 || nota > 10) {
			nota = parseInt(prompt("Error. Reingrese la nota del alumno " + i));
		}

		sexo = prompt("Ingrese el sexo del alumno " + i);
		while (sexo != "f" && sexo != "m") {
			sexo = prompt("Error. Reingrese el sexo del alumno " + i);
		}

		if (nota < notaBaja || i == 1) {
			notaBaja = nota;
			notaBajaAlum = i;
		}

		if (nota >= 6) {
			varones++;

		}
		suma = suma + nota;
		promedio = suma / i;




	}

alert("El promedio de las notas es de " + promedio);
alert("La nota mas baja fue de " + notaBaja + " del alumno " + notaBajaAlum);
alert(varones + " varon/es se han sacado 6 o mas en el examen");


}

