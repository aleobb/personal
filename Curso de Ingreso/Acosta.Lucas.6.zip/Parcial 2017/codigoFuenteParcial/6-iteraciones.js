//Debemos lograr mostrar un mensaje al presionar el botón  'MOSTRAR'.
function Mostrar() {
	alert("Funciona 6-iteraciones");

	var importe;
	var max;
	var min;
	var maxDia;
	var minDia;

	for (i = 1; i <= 7; i++) {
		importe = parseInt(prompt("Ingrese el importe para el dia " + i));
		while (isNaN(importe) || importe < 1) {
			importe = parseInt(prompt("Error. Reingrese el importe del dia " + i));
		}

		if (importe < min || i == 1) {
			min = importe;
			minDia = i;
		}

		if (importe > max || i == 1) {
			max = importe;
			maxDia = i;
		}


	}

	document.write("El mayor importe de venta fue " + max + " para el dia " + maxDia + "</br>");
	document.write("El menor importe de venta fue " + min + " para el dia " + minDia + "</br>");


}

